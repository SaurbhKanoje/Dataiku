# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import dataiku
import pandas as pd
from datetime import datetime
import logging
import time

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

host = "https://dataiku-dev-vm1.zurich.com/"
environment = "OnPrem Prod"
dss_type = "DESIGN"

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
client = dataiku.api_client()
projects = client.list_projects()
log.info(f"Number of projects: {len(projects)}")
projects = [p for p in projects if len(client.get_project(p["projectKey"]).list_jobs()) > 1 if (datetime.fromtimestamp(time.time()) - max([datetime.fromtimestamp(p["startTime"]/1000) for p in client.get_project(p["projectKey"]).list_jobs()])).days < 90]
log.info(f"Number of projects with at least one job done in the last 90 days: {len(projects)}")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
projects

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
results_df = pd.DataFrame(columns=['host','environment','dss_type','project','owner', 'active_users', 'nb_jobs_last_year', 'max_job_date','list_of_users','description'])

for p in projects :
    list_of_jobs = client.get_project(p["projectKey"]).list_jobs()

    owner = client.get_project(p["projectKey"]).get_summary()['ownerLogin']
    unique_active_users = len(set([p["def"]["initiator"] for p in list_of_jobs]))
    list_of_users = list(set([p["def"]["initiator"] for p in list_of_jobs]))

    nb_jobs_last_year = sum([(datetime.fromtimestamp(time.time()) - datetime.fromtimestamp(p["startTime"]/1000)).days < 90 for p in list_of_jobs])
    max_job_date = max([datetime.fromtimestamp(p["startTime"]/1000) for p in list_of_jobs])
    try:
        description = client.get_project(p["projectKey"]).get_summary()['description']
    except:
        description = ''
        
    results_df = results_df.append({'host':host,'environment':environment,'dss_type':dss_type,'project': p["projectKey"],'owner':owner, 'active_users':unique_active_users, 'nb_jobs_last_year':nb_jobs_last_year, 'max_job_date':max_job_date,'list_of_users':list_of_users,'description':description}, ignore_index=True)


# Write recipe outputs
bu_Projects = dataiku.Dataset("BU_Projects")
bu_Projects.write_with_schema(results_df)
