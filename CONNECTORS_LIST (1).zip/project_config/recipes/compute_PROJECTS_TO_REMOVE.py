# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import dataikuapi
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

client = dataiku.api_client()
project_keys = client.list_project_keys()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
project_key = "TEST_REMOVE"

def clear_all_project_data(projects):
    for i in projects:
        datasets = dataiku.Dataset.list(i)
        for dataset in datasets:
            param = dataiku.Dataset(dataset,project_key).get_location_info()#["locationInfoType"]
            dataikuapi.dss.dataset.DSSDataset(client,project_key,dataset).clear()

def remove_project_with_data(projects):
    for i in projects:
        dataikuapi.dss.project.DSSProject(client, i).delete(clear_managed_datasets=True, clear_output_managed_folders=True)
        print("The project: " + i + " has been deleted")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
remove_project_with_data(["TEST_REMOVE"])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

PROJECTS_TO_REMOVE_df = ... # Compute a Pandas dataframe to write into PROJECTS_TO_REMOVE


# Write recipe outputs
PROJECTS_TO_REMOVE = dataiku.Dataset("PROJECTS_TO_REMOVE")
PROJECTS_TO_REMOVE.write_with_schema(PROJECTS_TO_REMOVE_df)