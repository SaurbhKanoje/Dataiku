# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import json
# Read recipe inputs
users_logs = dataiku.Dataset("users_logs")
users_logs_df = users_logs.get_dataframe()
logs = users_logs_df['col_0']

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
from IPython.core.interactiveshell import InteractiveShell

InteractiveShell.ast_node_interactivity = "all"

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#for i in logs[0:10000000]:
#    if 'apiCall' in i and 'joseba.elcano' in i and not 'check-dataset-read-privilege' in i and not 'activity-started' in i and not 'scenario-run' in i:
#        print(i)
#        print('\n')

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
logins = pd.DataFrame(columns=['user','date','callpath'])
errors = []
message_login = 0
for i in logs:
    try:
        var = json.loads(i)
        if 'apiCall' in var['mdc'].keys():
            if var['mdc']['apiCall'] == '/api/login':
                logins = logins.append({'user': var['message']['login']  ,'date':var['timestamp'],'callpath':var['mdc']['apiCall'] }, ignore_index=True)
                if 'login'in var['message'].keys():
                    message_login = message_login + 1
    except:
        errors.append(i)
        pass

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
logins.user = logins.user.apply(lambda x: x.lower())
logins.user = logins.user.apply(lambda x: x.split("@", 1)[0])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
for i in logins.user:
    print(i)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
log_in_info_df = logins # For this sample code, simply copy input to output



# Write recipe outputs
log_in_info = dataiku.Dataset("Log_in_info")
log_in_info.write_with_schema(log_in_info_df)