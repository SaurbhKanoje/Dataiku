# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from datetime import datetime
import logging
import time


client = dataiku.api_client()
projects = client.list_projects()
#log.info(f"Number of projects: {len(projects)}")
#projects = [p for p in projects if len(client.get_project(p["projectKey"]).list_jobs()) > 1 if (datetime.fromtimestamp(time.time()) - max([datetime.fromtimestamp(p["startTime"]/1000) for p in client.get_project(p["projectKey"]).list_jobs()])).days < 90]
#log.info(f"Number of projects with at least one job done in the last 90 days: {len(projects)}")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#projects[5]
#'19_GL_AP_AUOUNDERWRITINGONEPATHLIFE'
# '19_GL_EU_SJOASSETMANAGERSABAMSPAINBSVBSP'
#client.get_project('19_GL_EU_SJOASSETMANAGERSABAMSPAINBSVBSP').get_permissions()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
results_df = pd.DataFrame(columns=['projectKey','ownerLogin','last_job','last_modify','creation_date', 'permissions'])
count = 0
for p in projects :
    try:
        #print(count)
        count = count+1
        list_of_jobs = client.get_project(p["projectKey"]).list_jobs()
        permissions = client.get_project(p["projectKey"]).get_permissions()['permissions']
        results_df = results_df.append({'projectKey':p['projectKey'],'ownerLogin':p['ownerLogin'],'last_job':time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(list_of_jobs[0]['startTime'])/1000)), 'last_modify' : 'NA', 'creation_date' : p['checklists']['checklists'][0]['items'][0]['createdOn'], 'permissions' : permissions  }, ignore_index=True)
    except:
        list_of_jobs = client.get_project(p["projectKey"]).list_jobs()
        results_df = results_df.append({'projectKey':p['projectKey'],'ownerLogin':p['ownerLogin'],'last_job': 'No Jobs', 'last_modify' :'NA', 'creation_date' :'NA', 'permissions' : permissions}, ignore_index=True)
#    list_of_jobs = client.get_project(p["projectKey"]).list_jobs()
#    print('list_of_jobs')
#    print(' ')

# list_of_jobs[-1] #feb 2022
    #projects_with_owner_df = results_df.append({'host':host,'environment':environment,'dss_type':dss_type,'project': p["projectKey"],'owner':owner, 'active_users':unique_active_users, 'nb_jobs_last_year':nb_jobs_last_year, 'max_job_date':max_job_date,'list_of_users':list_of_users,'description':description}, ignore_index=True)

# Write recipe outputs
projects_with_owner = dataiku.Dataset("Projects_with_owner")
projects_with_owner.write_with_schema(results_df)