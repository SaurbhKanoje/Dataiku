# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import ast

# Read recipe inputs
users_mapped = dataiku.Dataset("Users_mapped")
users_mapped_df = users_mapped.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users = users_mapped_df[users_mapped_df['enabled'] == True]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users['groups'] = users['groups'].apply(lambda x: ast.literal_eval(x))

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
for i in users.index:
    if len(users['groups'][i]) < 2:
        print(users['user_name'][i],users['license'][i], users['groups'][i] )
    else:
        users.drop([i], inplace = True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

users_GROUPS_df = users # For this sample code, simply copy input to output


# Write recipe outputs
users_GROUPS = dataiku.Dataset("users_GROUPS")
users_GROUPS.write_with_schema(users_GROUPS_df)