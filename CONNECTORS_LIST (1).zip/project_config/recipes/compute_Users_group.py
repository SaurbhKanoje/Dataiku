# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu


# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

client = dataiku.api_client()
userslist = client.list_users()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users_info = pd.DataFrame(columns=['user_name','license','enabled', 'email', 'groups'])
for i in userslist:
    if 'email' in i.keys():
        users_info = users_info.append({'user_name': i['login']  ,'license':i['userProfile'],'enabled':i['enabled'], 'email' : i['email'], 'groups' : i['groups'] }, ignore_index=True)
    else:
        users_info = users_info.append({'user_name': i['login']  ,'license':i['userProfile'],'enabled':i['enabled'], 'email' : 'NaN', 'groups' : i['groups'] }, ignore_index=True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#users_info.user_name = users_info.user_name.apply(lambda x: x.lower())


users_group_df = users_info # Compute a Pandas dataframe to write into Users_group


# Write recipe outputs
users_group = dataiku.Dataset("Users_group")
users_group.write_with_schema(users_group_df)
