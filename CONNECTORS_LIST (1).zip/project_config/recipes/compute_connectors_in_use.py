import dataiku
import pandas as pd
from datetime import datetime

client = dataiku.api_client()
projects = client.list_projects()
result_df = pd.DataFrame(columns=['project', 'connection', 'type', 'name', 'last_modified'])

for p in projects :
    proj = client.get_project(p["projectKey"])
    datasets = []
    all_datasets = proj.list_datasets()
    for dataset in all_datasets:
        ds_type = dataset['type']
        if ds_type == 'HTTP':
            links = ''
            for i in dataset['params']['sources']:
                links += str(i['url']) + '\n'
            ds_name = links
        else:
            ds_name = dataset['name']

        if 'creationTag' not in dataset:
            last_modified = float('NaN')
        else:
            last_modified = datetime.fromtimestamp(dataset['creationTag']['lastModifiedOn']/1000)

        try:
            connection = dataset["params"]["connection"]
        except KeyError:
            connection = "unlisted connection"
        result_df = result_df.append({'project': p["projectKey"], 'connection': connection,'type': ds_type,'name':ds_name, 'last_modified':last_modified }, ignore_index=True)

# Write recipe outputs
connectors_in_use = dataiku.Dataset("connectors_in_use")
connectors_in_use.write_with_schema(result_df)
