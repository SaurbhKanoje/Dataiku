# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

client = dataiku.api_client()
userslist = client.list_users()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users_info = pd.DataFrame(columns=['user_name','license','enabled', 'email', 'groups'])
for i in userslist:
    if 'email' in i.keys():
        users_info = users_info.append({'user_name': i['login']  ,'license':i['userProfile'],'enabled':i['enabled'], 'email' : i['email'], 'groups' : i['groups'] }, ignore_index=True)
    else:
        users_info = users_info.append({'user_name': i['login']  ,'license':i['userProfile'],'enabled':i['enabled'], 'email' : 'NaN', 'groups' : i['groups'] }, ignore_index=True)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users_info.user_name = users_info.user_name.apply(lambda x: x.lower())

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users_mapped_df = users_info # Compute a Pandas dataframe to write into Users_mapped


# Write recipe outputs
users_mapped = dataiku.Dataset("Users_mapped")
users_mapped.write_with_schema(users_mapped_df)

