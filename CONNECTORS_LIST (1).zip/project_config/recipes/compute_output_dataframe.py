# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import subprocess

# Read recipe inputs
model_dir = dataiku.Folder("qhy4zs1T")
model_dir_info = model_dir.get_info()
folder_path = model_dir.get_path()
paths = model_dir.list_paths_in_partition()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import os


for i in paths:
    if ".accdb" in i:    
        os.chdir(f"{folder_path}")
        os.system(f"bash /data/mdb-export-all.sh {folder_path}{i}")
        
csv_file = i[:-4] + ".csv"
dataset = pd.read_csv(f'{folder_path}{csv_file}')

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
output_dataframe_df = dataset # Compute a Pandas dataframe to write into output_dataframe


# Write recipe outputs
output_dataframe = dataiku.Dataset("output_dataframe")
output_dataframe.write_with_schema(output_dataframe_df)