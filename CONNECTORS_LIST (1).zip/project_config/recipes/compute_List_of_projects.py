# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu


import dataiku
import pandas as pd
from datetime import datetime

client = dataiku.api_client()
projects = client.list_projects()

result_df = pd.DataFrame(columns=['project'])

for p in projects :

    result_df = result_df.append({'project': p["projectKey"],}, ignore_index=True)
    
list_of_projects_df = result_df # Compute a Pandas dataframe to write into List_of_projects


# Write recipe outputs
list_of_projects = dataiku.Dataset("List_of_projects")
list_of_projects.write_with_schema(list_of_projects_df)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
list_of_projects_df