# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from datetime import datetime
import time
from datetime import date
# Read recipe inputs
users_mapped_joined = dataiku.Dataset("Users_mapped_joined")
users_mapped_joined_df = users_mapped_joined.get_dataframe()
users = users_mapped_joined_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
for i in range(len(users)):
    try:
        users['date_max'][i] =  datetime.strptime(users['date_max'][i][0:10], '%Y-%m-%d').date()
    except:
        users['date_max'][i] = np.datetime64('NaT')

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
for i in range(len(users)):
    try:
        users['job_def_initiated_max'][i] =  users['job_def_initiated_max'][i].date()
    except:
        users['job_def_initiated_max'][i] = float('nan')

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
keep_users = ["a.perilli",
"akhilesh.mehta",
"anamika.roy",
"c.baseler",
"c.fujishimasalinas",
"Carrie.Chung",
"CHRIS.WONG3",
"D.NEGRETEVAZQUEZ",
"dayane.lima",
"deevya.sethi",
"denzil.taylor",
"doriana.mastrovito",
"fatima.camargo",
"fernando.carvajal",
"foued.benkhalifa",
"g.fuenzalida",
"g.mendesmeirelles",
"GAUSS.CHENG",
"gergo.havasi",
"gonzalo.laplume",
"jaehyup.chun",
"jennifer.tomforde",
"jessica.l.shields",
"jevin.chee",
"josef.tureini",
"juliane.bellini",
"k.yung",
"kamineswary.pakalan",
"karly.lau1",
"KENICHI.KATO",
"kimberley.proudlock",
"kristina.kobus",
"lily.chen1",
"lucas.nistor",
"martin.wales",
"Matthias.Pulver",
"nurulafiqah.othman",
"PATRICIA.CEVALLOS",
"phil.knowles",
"philip.ouma",
"rebekah.coote",
"ririn.farianti",
"sabine.gutt",
"SONIA.RAMIREZ1",
"subhadip.dey",
"tim.barnes",
"v.tartaglia",
"wan.nurlianaadabi",
"zan.mokran",
"ava.dossi",
"DREW.GARCIA1",
"f.bustelosoto",
"james.foresto",
"maciej.turecki",
"michele.berto",
"nicolas.ferrer",
"sabrina.patterson",
"siuyu.wu"]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users = users[~users['user_name'].isin(keep_users)]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users = users[users['enabled'] == True]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users[users['date_max'] < datetime(2020,8,23).date()]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#type(users['date_max'][1])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#type(users['job_def_initiated_max'][1])


users_to_be_disabled_df = users # For this sample code, simply copy input to output



# Write recipe outputs
users_to_be_disabled = dataiku.Dataset("users_to_be_disabled")
users_to_be_disabled.write_with_schema(users_to_be_disabled_df)