# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import subprocess

client = dataiku.api_client()
dss_projects = client.list_project_keys()
uploads_dir = "/data/dataiku/uploads/"
projects_dir = "/data/dataiku/project_folders/"


#print(dss_projects[0])
#print(client.get_project(dss_projects[0]).get_project_folder())

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
def get_project_paths(project_key):
    project = client.get_project(project_key)
    all_datasets = project.list_datasets()
    list_folders = []
    for i in all_datasets:
        if i["type"] == "UploadedFiles":
            specific_upload_folder_dir = uploads_dir+project_key
            #print(specific_upload_folder_dir)
            if specific_upload_folder_dir not in list_folders:
                list_folders.append(specific_upload_folder_dir)
        specific_folder_dir = projects_dir+project_key
        if specific_folder_dir not in list_folders:
            list_folders.append(specific_folder_dir)
    return list_folders

def sizes(dir_list):
    sizes = []
    for i in dir_list:
        size = subprocess.getoutput(f"du --max-depth=0 {i}")
        size = size.split("\t/")[0]
        if "cannot" in size:
            sizes.append(0)
        else:
            sizes.append(size)
    return sizes

df = pd.DataFrame()
for i in dss_projects:
    sizes_list = sizes(get_project_paths(i))
 
    try:
        df = df.append({'project_key' : i, 'size' : int(sizes_list[0]) + int(sizes_list[1]) }, ignore_index = True)
    except:
        df = df.append({'project_key' : i, 'size' :'0', }, ignore_index = True)




project_sizes_df = df # Compute a Pandas dataframe to write into project_sizes


# Write recipe outputs
project_sizes = dataiku.Dataset("project_sizes")
project_sizes.write_with_schema(project_sizes_df)