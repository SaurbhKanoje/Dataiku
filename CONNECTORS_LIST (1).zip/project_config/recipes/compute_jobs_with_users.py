# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
dss_jobs = dataiku.Dataset("dss_jobs")
dss_jobs_df = dss_jobs.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jobs = dss_jobs_df[["job_def_initiator","job_def_initiated"]][dss_jobs_df['job_def_trigger_type'] != 'SCHEDULER']

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jobs.job_def_initiator = jobs.job_def_initiator.apply(lambda x: x.lower())

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dss_jobs_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jobs_with_users_df = jobs # For this sample code, simply copy input to output


# Write recipe outputs
jobs_with_users = dataiku.Dataset("jobs_with_users")
jobs_with_users.write_with_schema(jobs_with_users_df)