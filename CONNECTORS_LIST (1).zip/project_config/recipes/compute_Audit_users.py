# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu



# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dataiku_current = dataiku.api_client()
userslist = dataiku_current.list_users()
audit_users_list = []
for user in userslist:
    groups = user['groups']
    if 'Group_Audit' in groups:
        audit_users_list.append(user['login'])
audit_users_list

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE

Audit_users_df = pd.DataFrame(audit_users_list) # Compute a Pandas dataframe to write into Audit_users


# Write recipe outputs
Audit_users = dataiku.Dataset("Audit_users")
Audit_users.write_with_schema(Audit_users_df)