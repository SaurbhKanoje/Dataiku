# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

client = dataiku.api_client()
connections = client.list_connections()
connections_output = pd.DataFrame(columns=['connection', 'type', 'connection details'])

for connection in connections:
    connection_str = str(connection)
    type_con = str(connections[connection_str]['type'])

    if type_con == 'JDBC':
        details = 'JDBC driver class: ' + connections[connection_str]['params']['driver'] +'\n'+ 'JDBC URL: ' + connections[connection_str]['params']['jdbcurl']

    elif type_con == 'Oracle':
        try:
            details = 'Connection URL: ' + connections[connection_str]['params']['url']
        except:
            continue

    elif type_con == 'PostgreSQL':
        details = 'Host: ' + connections[connection_str]['params']['host'] +'\n'+  'Databse: ' + connections[connection_str]['params']['db'] +'\n'+ 'Ports: ' + str(connections[connection_str]['params']['port'])

    elif type_con == 'MySQL':
        details = 'Host: ' + connections[connection_str]['params']['host'] +'\n'+  'Databse: ' + connections[connection_str]['params']['db'] +'\n'+ 'Ports: ' + str(connections[connection_str]['params']['port'])

    elif type_con == 'SQLServer':
        if 'host' in connections[connection_str]['params'].keys():
            details = 'Host: ' + connections[connection_str]['params']['host'] +'\n'+  'Databse: ' + connections[connection_str]['params']['db'] +'\n'+ 'Ports: ' + str(connections[connection_str]['params']['port'])
        else:
            details = 'URL: ' + connections[connection_str]['params']['url']

    elif type_con == 'Azure':
        if 'chcontainer' in connections[connection_str]['params'].keys():
            details = 'Azure Storage account: ' + connections[connection_str]['params']['storageAccount'] +'\n'+  'Auth type: ' + connections[connection_str]['params']['authType'] +'\n'+ 'Container: ' + connections[connection_str]['params']['chcontainer']
        else:
            details = 'Azure Storage account: ' + connections[connection_str]['params']['storageAccount'] +'\n'+  'Auth type: ' + connections[connection_str]['params']['authType'] +'\n'+ 'Container: ' + 'NA'


    elif type_con == 'HDFS':
        details = 'Root path URI: ' + connections[connection_str]['params']['root']

    else:
        details = 'Root path: ' + connections[connection_str]['params']['root']

    connections_output = connections_output.append({'connection': connection_str, 'type': type_con, 'connection details' : details}, ignore_index=True)


# Write recipe outputs
all_list_instance = dataiku.Dataset("All_list_instance")
all_list_instance.write_with_schema(connections_output)