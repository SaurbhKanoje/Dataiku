# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
dss_jobs = dataiku.Dataset("dss_jobs")
dss_jobs_df = dss_jobs.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#jobs = dss_jobs_df[["job_project_key","job_def_initiator","job_def_initiated"]][dss_jobs_df['job_def_trigger_type'] != 'SCHEDULER']

jobs = dss_jobs_df[["job_project_key","job_def_initiator","job_def_initiated"]]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
jobs

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
USERS_AND_PROYECTS = dataiku.Dataset("USERS_AND_PROYECTS")
USERS_AND_PROYECTS.write_with_schema(jobs)