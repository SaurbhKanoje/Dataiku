# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import os, json
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import dataikuapi
import pandas as pd
# Read recipe inputs
group_Audit = dataiku.Dataset("GRoup_Audit")
group_Audit_df = group_Audit.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
users = group_Audit_df['user_name'].tolist()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
path_to_json = '/data/dataiku/config/general-settings.json'
with open(path_to_json) as jsonFile:
    jsonObject = json.load(jsonFile)
    jsonFile.close()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
impersonations = jsonObject['impersonation']

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
impersonations['userRules'][0]

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
i

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
ya_impersonados =[]
for i in impersonations['userRules']:
    try:
        if i['dssUser'] in users:
            ya_impersonados.append(i['dssUser'])
    except :
        pass
ya_impersonados

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
para_impersonar = []
for i in users:
    if i not in ya_impersonados:
        para_impersonar.append(i)
para_impersonar

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
len(para_impersonar)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# ## Framework to impesonate different users at once

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import dataiku
import dataikuapi

def impersonate_user(user):
    # Retrieve client
    client = dataiku.api_client()

    #create impersonation rule object for userA and groups
    user_impersonation_rule = dataikuapi.dss.admin.DSSUserImpersonationRule(raw=None)


    #Define scope and mapping rules
    user_impersonation_rule.scope_global()
    user_impersonation_rule.user_single(dss_user=user, unix_user='y1030865', hadoop_user=None)


    # Add impersonation rule by retrieving general settings first, adding the rules, and then saving the changes
    general_settings = client.get_general_settings()
    general_settings.add_impersonation_rule(user_impersonation_rule, is_user_rule=True)
    general_settings.save()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
for i in para_impersonar:
    impersonate_user(i)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
impersonations

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#En global

dicts = []

for i in users:
    new = {}
    new['dssUser'] = i
    new['scope'] = 'GLOBAL'
    new['targetUnix'] ='y1030865'
    new['type'] = 'SINGLE_MAPPING'
    dicts.append(new)
dicts

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# por projecto

dicts = []

for i in users:
    for a in project_keys:
    new = {}
    new['dssUser'] = i
    new['projectKey'] = a
    new['scope'] = 'PROJECT'
    new['targetUnix'] ='y1030865'
    new['type'] = 'SINGLE_MAPPING'
    dicts.append(new)
dicts

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
{u'dssUser': u' JOSEBA.ELCANO',
   u'scope': u'GLOBAL',
   u'targetUnix': u'y1030865',
   u'type': u'SINGLE_MAPPING'}

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
host = "http://dataiku.zurich.com:11000/"
apiKey = "JR1HLOPP4UPPRCVWOA1VR3AYLPV2QBRF"
client = client = dataiku.api_client()
#client = dataikuapi.DSSClient(host, apiKey)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#create impersonation rule object
impersonation_rule = dataikuapi.dss.admin.DSSUserImpersonationRule()
#result 
impersonation_rule.__dict__

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#global all projects
impersonation_rule.scope_project('CONNECTORS_LIST')

#impersonation_rule.scope_global()
#result 
impersonation_rule.__dict__

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#DSS user and UNIX user
impersonation_rule.user_single(dss_user='fatima.camargo', unix_user='y1030865', hadoop_user=None)
#result 
impersonation_rule.__dict__

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#result 
impersonation_rule.__dict__

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# implementing change
dataikuapi.dss.admin.DSSGeneralSettings(client).add_impersonation_rule(impersonation_rule, is_user_rule=False)
#, is_user_rule=True
dataikuapi.dss.admin.DSSGeneralSettings(client).save()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
impersonation_rule.__dict__['raw']

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
dataikuapi.DSSClient.get_general_settings(client).get_impersonation_rules().__dict__

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
help(impersonation_rule)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE

adding_impersonation_df = group_Audit_df # For this sample code, simply copy input to output


# Write recipe outputs
adding_impersonation = dataiku.Dataset("adding_impersonation")
adding_impersonation.write_with_schema(adding_impersonation_df)