# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu


import dataiku
import pandas as pd
from datetime import datetime

client = dataiku.api_client()
projects = client.list_projects()

result_df = pd.DataFrame(columns=['project', 'owner'])

for p in projects :

    result_df = result_df.append({'project': p["projectKey"], 'owner': p['ownerLogin']}, ignore_index=True)

user_project_owner_df = result_df # Compute a Pandas dataframe to write into user_project_owner

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE

# Write recipe outputs
user_project_owner = dataiku.Dataset("user_project_owner")
user_project_owner.write_with_schema(user_project_owner_df)