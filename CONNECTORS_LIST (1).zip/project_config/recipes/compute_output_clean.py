# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
Audit_users_joined_by_project_prepared = dataiku.Dataset("Audit_users_joined_by_project_prepared")
Audit_users_joined_by_project_prepared_df = Audit_users_joined_by_project_prepared.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

output_clean_df = Audit_users_joined_by_project_prepared_df # For this sample code, simply copy input to output

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE


output_clean_df['project_copy'] = output_clean_df['project_copy'].apply(lambda x: x.replace('_', ''))
output_clean_df['name_connector_concat_copy'] = output_clean_df['name_connector_concat_copy'].apply(lambda x: x.replace('_', ''))

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE

output_clean_df['flag'] = output_clean_df.apply(lambda x: str(x.project_copy) in str(x.name_connector_concat_copy), axis=1)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
output_clean_df

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
output_clean_df = output_clean_df[output_clean_df['flag'] == False]
# Write recipe outputs
output_clean = dataiku.Dataset("output_clean")
output_clean.write_with_schema(output_clean_df)