# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu


client = dataiku.api_client()
dss_users = client.list_users()

user_list = []
# Grab list of users where they have active web socket sessions
for user in dss_users:
    if user['activeWebSocketSesssions'] != 0:
        user_list.append(user['displayName'])
print (user_list)
# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.


current_Users_logged_in_df = pd.DataFrame(user_list) # Compute a Pandas dataframe to write into current_Users_logged_in


# Write recipe outputs
current_Users_logged_in = dataiku.Dataset("current_Users_logged_in")
current_Users_logged_in.write_with_schema(current_Users_logged_in_df)
