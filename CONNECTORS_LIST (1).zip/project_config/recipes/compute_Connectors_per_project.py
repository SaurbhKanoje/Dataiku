# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
client = dataiku.api_client()
dss_projects = client.list_project_keys()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
#client.get_project(dss_projects[0]).get_summary()['ownerLogin']

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
frame = pd.DataFrame(columns=['project','owner',  'type_connector','name_connector'])
for project in dss_projects:

    connectors_per_project = client.get_project(project).list_datasets()

    for connectors in connectors_per_project:

 #       print(connectors['params'])
        if 'uploadConnection' in connectors['params']:
#            print(project, 'uploadConnection', connectors['params']['uploadConnection'])
            frame = frame.append({'project' : project,'owner': client.get_project(project).get_summary()['ownerLogin'], 'type_connector' : 'uploadConnection','name_connector':connectors['params']['uploadConnection']}, ignore_index=True)
        if 'connection' in connectors['params']:
#            print(project, 'connection', connectors['params']['connection'])
            frame = frame.append({'project' : project,'owner':client.get_project(project).get_summary()['ownerLogin'] , 'type_connector' : 'connection','name_connector':connectors['params']['connection']}, ignore_index=True)
        if 'uploadConnection' not in connectors['params'] and 'connection' not in 'connection':
#            print('')
            print(connectors['params'])

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
frame
Connectors_per_project_df = frame.drop_duplicates() # Compute a Pandas dataframe to write into Connectors_per_project


# Write recipe outputs
Connectors_per_project = dataiku.Dataset("Connectors_per_project")
Connectors_per_project.write_with_schema(Connectors_per_project_df)