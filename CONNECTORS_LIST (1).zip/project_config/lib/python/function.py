

def give_me():
    print('hello')
    return True